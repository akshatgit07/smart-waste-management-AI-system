import requests
from config.settings import OPENWEATHER_API_KEY

def get_weather_alert(city):
    """Fetches weather conditions to check waste collection delays."""
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        weather = data["weather"][0]["description"]
        temp = round(data["main"]["temp"] - 273.15, 2)  # Convert Kelvin to Celsius
        return f"Weather: {weather}, Temperature: {temp}°C"
    return "Invalid city or weather data unavailable."
