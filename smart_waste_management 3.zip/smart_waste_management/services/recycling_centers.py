import googlemaps
from config.settings import GOOGLE_MAPS_API_KEY

import requests
from config.settings import IWASTE_API_URL

import streamlit as st 

def get_disposal_facilities(state_code, facility_type_id):
    """Fetches the nearest disposal facilities based on state and selected type."""
    if not state_code or not facility_type_id:
        return {"error": "Missing parameters, cannot fetch disposal facilities."}

    url = f"{IWASTE_API_URL}/facilities?stateCode={state_code}&facilityTypeId={facility_type_id}"

    response = requests.get(url)
    #st.write(f"API Request: {url}")  # Debugging
    #st.write(f"API Status Code: {response.status_code}")  # Debugging

    if response.status_code == 200:
        data = response.json()
        #st.write(f"API Response: {data}")  # Debugging
        
        return data.get("data", [])  # Extract 'data' list from response

    return {"error": "No facilities found for this state and facility type."}
