import requests
from config.settings import IWASTE_API_URL

def get_waste_categories():
    """Fetches waste category classifications from I-WASTE API."""
    response = requests.get(f"{IWASTE_API_URL}/categories")
    return response.json() if response.status_code == 200 else {"error": "No categories available"}

def get_waste_parameters():
    """Fetches waste parameters from I-WASTE API."""
    response = requests.get(f"{IWASTE_API_URL}/parameters")
    return response.json() if response.status_code == 200 else {"error": "No parameters available"}

def estimate_waste(material_type, quantity):
    """Estimates waste impact using I-WASTE API."""
    url = f"{IWASTE_API_URL}/waste-calc"
    data = {"material": material_type, "quantity": quantity}
    response = requests.post(url, json=data)
    return response.json() if response.status_code == 200 else {"error": "Failed to estimate waste"}

def get_waste_facilities():
    """Fetches available waste disposal facilities."""
    response = requests.get(f"{IWASTE_API_URL}/facilities")
    return response.json() if response.status_code == 200 else {"error": "No facilities found"}

def get_disposal_facility_types():
    """Fetches disposal facility types."""
    response = requests.get(f"{IWASTE_API_URL}/disposal-facility-subtypes")
    return response.json() if response.status_code == 200 else {"error": "No facility types available"}

def get_epa_regions():
    """Fetches EPA regions for location-based waste insights."""
    response = requests.get(f"{IWASTE_API_URL}/epa-regions")
    return response.json() if response.status_code == 200 else {"error": "No EPA regions available"}

def get_us_states():
    """Fetches US states for location-based waste information."""
    response = requests.get(f"{IWASTE_API_URL}/us-states")
    return response.json() if response.status_code == 200 else {"error": "No US states available"}
