import openai
import requests
import base64
from config.settings import OPENAI_API_KEY, IWASTE_API_URL

def classify_waste(waste_item):
    """Uses OpenAI API to classify waste and match it with I-WASTE categories."""
    
    # Fetch categories from I-WASTE API
    response = requests.get(f"{IWASTE_API_URL}/categories")
    if response.status_code != 200:
        return {"error": "Failed to fetch waste categories"}

    waste_categories = response.json()

    # Convert the categories into a text format for AI to process
    category_text = "\n".join([f"{cat['id']}: {cat['name']}" for cat in waste_categories])

    # Use OpenAI to determine the best matching category
    prompt = f"""
You are an expert in waste classification and disposal.

### Task:
A user wants to dispose of an item. Your job is to **correctly classify it** based on the list of waste categories and provide a brief explanation.

### Instructions:
- Identify the most **accurate waste category** from this list:
  {category_text}
- If multiple categories fit, choose **the most relevant one**.
- If the item is **electronic**, classify it under **"Electronic Waste"**.
- If it is **plastic**, classify it under **"Plastic Waste"**.
- If unsure, return: **'Unknown Category'**.

### Expected Output Format:
1️⃣ **Category:** [Category Name]  
2️⃣ **Explanation:** [Brief reason why it belongs in this category]  

### Example Outputs:
- **Plastic Bottle** → **Plastic Waste**  
  *Explanation: Plastic bottles are typically made from PET plastic, which is recyclable and falls under the plastic waste category.*
- **Laptop** → **Electronic Waste**  
  *Explanation: Laptops contain electronic components, circuits, and batteries, making them hazardous electronic waste.*
- **AA Battery** → **Battery Waste**  
  *Explanation: Batteries contain chemicals that need special recycling processes to avoid environmental harm.*

### Waste Item:
{waste_item}

💡 **Return both the category and explanation as a structured response.**
"""



    openai.api_key = OPENAI_API_KEY
    try:
        client = openai.OpenAI()
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )

        return response.choices[0].message.content if response.choices else "Unknown Category"
    
    except Exception as e:
        return {"error": f"OpenAI API Error: {str(e)}"}

def analyze_image(image_file):
    """Uses OpenAI GPT-4 Turbo Vision API to analyze an image and describe the waste item."""
    openai.api_key = OPENAI_API_KEY

    try:
        # Read image and encode to base64
        image_bytes = image_file.read()
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')

        client = openai.OpenAI()
        response = client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": 
                    "You are a waste classification AI. Identify objects in the image "
                    "and categorize them into relevant waste types like 'Electronic Waste', 'Plastic Waste', 'Battery Waste', etc."},
                {"role": "user", "content": [
                    {"type": "image", "image": image_base64},  
                    {"type": "text", "text": 
                        "Analyze this image and determine the dominant type of waste. "
                        "Only return a **single category** (e.g., 'Electronic Waste', 'Plastic Waste')."}
                ]}
            ]
        )

        return response.choices[0].message.content if response.choices else "Unknown Category"
    
    except Exception as e:
        return {"error": f"OpenAI Vision API Error: {str(e)}"}

