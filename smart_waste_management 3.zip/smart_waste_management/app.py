import pandas as pd
import streamlit as st
import datetime
import openai
import matplotlib.pyplot as plt
import seaborn as sns
import services.waste_classification as waste_classifier  # Fix circular import
import folium
from streamlit_folium import folium_static
from services.recycling_centers import get_disposal_facilities
from services.location_services import get_coordinates

# ----------- Streamlit UI Configuration ------------
st.set_page_config(page_title="♻️ Smart Waste Management", layout="wide")

# ----------- Custom CSS for Better Styling ------------
st.markdown("""
    <style>
        .main {
            background-color: #f5f7f9;
        }
        .big-font {
            font-size:20px !important;
            font-weight: bold;
        }
        .section-header {
            font-size:24px !important;
            font-weight: bold;
            color: #2e7d32;
        }
        .card {
            background-color: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 2px 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 10px;
        }
    </style>
""", unsafe_allow_html=True)

# ----------- App Header ------------
st.markdown("<h1 class='section-header'>♻️ Smart Waste Management System</h1>", unsafe_allow_html=True)
st.write("Helping users classify waste, find disposal centers, and estimate environmental impact.")

# Create a tabbed interface
tab1, tab2, tab3 = st.tabs(["🗑 Waste Classification", "📍 Find Disposal Centers", "📊 Waste Analytics"])

# ----------- 1️⃣ Waste Classification ------------
with tab1:
    st.markdown("<h2 class='section-header'>🗑 Waste Classification</h2>", unsafe_allow_html=True)

    # Let users choose input method
    input_method = st.radio("How would you like to classify waste?", ["Type Waste Item", "Upload an Image"])

    waste_item = None  # Initialize variable

    if input_method == "Type Waste Item":
        waste_item = st.text_input("Enter a waste item (e.g., Plastic Bottle):")

    elif input_method == "Upload an Image":
        uploaded_file = st.file_uploader("Upload an image of waste", type=["jpg", "png", "jpeg"])
        
        if uploaded_file:
            waste_item = waste_classifier.analyze_image(uploaded_file)  # ✅ Pass image to OpenAI Vision API

    if st.button("Classify Waste"):
        if waste_item:  # Ensure input is provided
            try:
                classification = waste_classifier.classify_waste(waste_item)  # Use OpenAI + I-WASTE
                
                if isinstance(classification, dict) and "error" in classification:
                    st.error(classification["error"])
                else:
                    st.markdown(f"<p class='big-font'>✅ Suggested Category:</p>", unsafe_allow_html=True)
                    st.success(classification)  # Display AI classification
            except Exception as e:
                st.error(f"⚠️ Error processing request: {str(e)}")
        else:
            st.warning("⚠️ Please enter a valid waste item or upload an image.")

# ----------- 2️⃣ Find Recycling Centers ------------

# Facility type mapping
facility_types = {
    "Landfill": "1",
    "Recycling Center": "3",
    "Hazardous Waste Facility": "4",
    "Composting Facility": "5"
}

with tab2:
    st.markdown("<h2 class='section-header'>📍 Find Disposal Centers</h2>", unsafe_allow_html=True)

    location = st.text_input("Enter a city or ZIP code:")
    facility_choice = st.selectbox("Select Facility Type:", list(facility_types.keys()))

    # ✅ Initialize `facilities`, `lat`, and `lng` to avoid "not defined" errors
    facilities = None
    lat, lng = None, None

    if st.button("Find Facilities"):
        if location:
            lat, lng, city, state_code = get_coordinates(location)

            if state_code is None:
                st.error("❌ Could not determine state. Please enter a valid city or ZIP code.")
            else:
                selected_type_id = facility_types[facility_choice]  # Get facility type ID
                facilities = get_disposal_facilities(state_code, selected_type_id)  # Fetch facilities

                if isinstance(facilities, list) and len(facilities) > 0:
                    st.markdown(f"<p class='big-font'>🏭 Available {facility_choice} Facilities:</p>", unsafe_allow_html=True)

                    for facility in facilities[:5]:  # Show top 5 results
                        facility_name = facility.get("name", "Unknown")
                        city = facility.get("city", "N/A")
                        state = facility.get("stateCode", "N/A")
                        facility_type = facility.get("facilitySubtypes", "Unknown Type")
                        phone = facility.get("contactPhone", "No Contact Info")

                        st.markdown(f"""
                        <div class='card'>
                            🏢 <b>{facility_name}</b>  
                            📍 {city}, {state}  
                            🏭 Type: {facility_type}  
                            📞 Contact: {phone}
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.error(f"⚠️ No {facility_choice} facilities found for {state_code}.")
        else:
            st.warning("⚠️ Please enter a valid location before searching.")

    # ✅ Ensure `facilities` exists before using map visualization
    if facilities and isinstance(facilities, list) and len(facilities) > 0 and lat and lng:
        st.markdown("<h3 class='section-header'>🗺 Facility Locations on Map</h3>", unsafe_allow_html=True)

        # ✅ Add a map visualization (Folium)
        m = folium.Map(location=[lat, lng], zoom_start=8)

        for facility in facilities:
            fac_lat = facility.get("latitude", lat)
            fac_lng = facility.get("longitude", lng)
            facility_name = facility.get("name", "Unknown")

            folium.Marker(
                location=[fac_lat, fac_lng],
                popup=f"<b>{facility_name}</b>",
                icon=folium.Icon(color="green", icon="info-sign")
            ).add_to(m)

        folium_static(m)
