import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# API Keys
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_MAPS_API_KEY = os.getenv("GOOGLE_MAPS_API_KEY")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
IWASTE_API_KEY = os.getenv("IWASTE_API_KEY")

# API Base URLs
IWASTE_API_URL = "https://iwaste.epa.gov/api"
GOOGLE_MAPS_API_URL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
OPENWEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"
